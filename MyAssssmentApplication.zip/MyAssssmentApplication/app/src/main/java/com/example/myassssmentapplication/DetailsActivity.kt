package com.example.myassssmentapplication

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class DetailsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Create views programmatically
        setContentView(createLayout())

        // Get entity data from intent extras
        val property1 = intent.getStringExtra("PROPERTY1") ?: ""
        val property2 = intent.getStringExtra("PROPERTY2") ?: ""
        val description = intent.getStringExtra("DESCRIPTION") ?: ""

        // Find views using system resources
        findViewById<TextView>(android.R.id.text1).text = property1
        findViewById<TextView>(android.R.id.text2).text = property2
        findViewById<TextView>(android.R.id.message).text = description
    }

    private fun createLayout(): android.view.View {
        val context = this
        val scrollView = android.widget.ScrollView(context).apply {
            setPadding(16, 16, 16, 16)
        }

        val linearLayout = androidx.appcompat.widget.LinearLayoutCompat(context).apply {
            orientation = androidx.appcompat.widget.LinearLayoutCompat.VERTICAL
        }

        // Add title
        val title = TextView(context).apply {
            text = "Entity Details"
            textSize = 24f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = android.view.Gravity.CENTER
            setPadding(0, 0, 0, 24)
        }
        linearLayout.addView(title)

        // Add property1
        val prop1 = TextView(context).apply {
            id = android.R.id.text1
            textSize = 18f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 0, 0, 8)
        }
        linearLayout.addView(prop1)

        // Add property2
        val prop2 = TextView(context).apply {
            id = android.R.id.text2
            textSize = 16f
            setPadding(0, 0, 0, 16)
        }
        linearLayout.addView(prop2)

        // Add description label
        val descLabel = TextView(context).apply {
            text = "Description:"
            textSize = 16f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 0, 0, 8)
        }
        linearLayout.addView(descLabel)

        // Add description
        val desc = TextView(context).apply {
            id = android.R.id.message
            textSize = 16f
            setTextColor(0xFF666666.toInt())
        }
        linearLayout.addView(desc)

        scrollView.addView(linearLayout)
        return scrollView
    }
}