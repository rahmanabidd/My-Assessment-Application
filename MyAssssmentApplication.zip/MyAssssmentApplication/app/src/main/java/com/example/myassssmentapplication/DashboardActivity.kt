package com.example.myassssmentapplication

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class DashboardActivity : AppCompatActivity() {

    private lateinit var viewModel: DashboardViewModel
    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var errorText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Create views programmatically instead of using XML
        setContentView(createLayout())

        // Initialize ViewModel
        viewModel = ViewModelProvider(this)[DashboardViewModel::class.java]

        val keypass = intent.getStringExtra("KEYPASS") ?: ""

        // Initialize views
        recyclerView = findViewById(android.R.id.list) // Use system resource
        progressBar = findViewById(android.R.id.progress) // Use system resource
        errorText = findViewById(android.R.id.text1) // Use system resource

        recyclerView.layoutManager = LinearLayoutManager(this)

        viewModel.entities.observe(this) { entities ->
            val adapter = EntityAdapter(entities) { entity ->
                val intent = Intent(this, DetailsActivity::class.java).apply {
                    putExtra("PROPERTY1", entity.property1)
                    putExtra("PROPERTY2", entity.property2)
                    putExtra("DESCRIPTION", entity.description)
                }
                startActivity(intent)
            }
            recyclerView.adapter = adapter
        }

        viewModel.loading.observe(this) { isLoading ->
            progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        }

        viewModel.error.observe(this) { error ->
            errorText.text = error
            errorText.visibility = if (error.isNotEmpty()) View.VISIBLE else View.GONE
        }

        viewModel.loadDashboard(keypass)
    }

    private fun createLayout(): View {
        val context = this
        val linearLayout = androidx.appcompat.widget.LinearLayoutCompat(context).apply {
            orientation = androidx.appcompat.widget.LinearLayoutCompat.VERTICAL
            setPadding(16, 16, 16, 16)
        }

        // Add title
        val title = TextView(context).apply {
            text = "Dashboard"
            textSize = 24f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = android.view.Gravity.CENTER
            setPadding(0, 0, 0, 16)
        }
        linearLayout.addView(title)

        // Add progress bar
        val progress = ProgressBar(context).apply {
            id = android.R.id.progress
            visibility = View.GONE
        }
        linearLayout.addView(progress)

        // Add error text
        val error = TextView(context).apply {
            id = android.R.id.text1
            setTextColor(0xFFFF0000.toInt())
            visibility = View.GONE
            setPadding(0, 0, 0, 16)
        }
        linearLayout.addView(error)

        // Add recycler view
        val recycler = RecyclerView(context).apply {
            id = android.R.id.list
            layoutParams = android.view.ViewGroup.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                android.view.ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        linearLayout.addView(recycler)

        return linearLayout
    }
}