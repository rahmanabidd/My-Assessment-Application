package com.example.myassssmentapplication

import org.junit.Test
import org.junit.Assert.*

class SimpleDashboardViewModelTest {

    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun testEntityDataClass() {
        val entity = Entity("test1", "test2", "test description")
        assertEquals("test1", entity.property1)
        assertEquals("test2", entity.property2)
        assertEquals("test description", entity.description)
    }
}