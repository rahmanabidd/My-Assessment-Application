package com.example.myassssmentapplication

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DashboardViewModel : ViewModel() {

    private val _entities = MutableLiveData<List<Entity>>()
    val entities: LiveData<List<Entity>> = _entities

    private val _loading = MutableLiveData<Boolean>()
    val loading: LiveData<Boolean> = _loading

    private val _error = MutableLiveData<String>()
    val error: LiveData<String> = _error

    private val apiService = RetrofitClient.instance

    fun loadDashboard(keypass: String) {
        _loading.value = true

        println("DEBUG: Loading dashboard with keypass: $keypass")

        // Create test data with explicit values
        val testEntities = listOf(
            Entity(property1 = "Name", property2 = "Abidur Rahman", description = "This is the name of the user"),
            Entity(property1 = "Email", property2 = "md.rahman33@live.vu.edu.au", description = "This is the student email. All the communication between student and lecturers are done by this email"),
            Entity(property1 = "Student ID", property2 = "s4683956", description = "This is the unique student ID"),
            Entity(property1 = "Course", property2 = "NIT3213", description = "Welcome to the course Mobile Application Development NIT3213"),
            Entity(property1 = "Status", property2 = "Active", description = "The student is current")
        )

        println("DEBUG: Test entities created: $testEntities")
        println("DEBUG: First entity: ${testEntities[0]}")
        println("DEBUG: First entity property1: ${testEntities[0].property1}")
        println("DEBUG: First entity property2: ${testEntities[0].property2}")

        _entities.value = testEntities
        _loading.value = false

        println("DEBUG: Test data set to LiveData")
    }
}